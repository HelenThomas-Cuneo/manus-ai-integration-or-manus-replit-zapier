# Replit Integration for Manus.ai

This directory contains a Replit project for receiving webhooks from Manus.ai.

## Setup

1.  **Import into Replit:** Click the "Run on Replit" button to import this project into your Replit account.
2.  **Environment Variables:** In the Replit secrets, add your `MANUS_API_KEY`.
3.  **Install Dependencies:** The `requirements.txt` file will be automatically used to install the necessary Python packages.
4.  **Run:** Click the "Run" button to start the webhook receiver.

## Webhook Receiver

The `main.py` file contains a simple Flask application that listens for incoming POST requests on the `/webhook` endpoint. When a request is received, it will print the JSON payload to the console.

## Customization

You can customize the `main.py` file to process the webhook payload as needed. For example, you could use the payload to trigger other actions, such as sending a notification or updating a database.

