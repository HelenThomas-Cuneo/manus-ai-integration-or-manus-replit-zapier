/**
 * Authentication configuration for Manus.ai
 * Uses API Key authentication
 */

const testAuth = (z, bundle) => {
  // Test the API key by making a simple request
  return z.request({
    url: 'https://api.manus-ai.com/v2/health',
    method: 'GET',
    headers: {
      'X-API-Key': bundle.authData.api_key
    }
  }).then((response) => {
    if (response.status !== 200) {
      throw new Error('Invalid API key');
    }
    // Return some user info if available
    return response.json || { status: 'authenticated' };
  });
};

module.exports = {
  type: 'custom',
  
  // Define the fields users will need to provide
  fields: [
    {
      key: 'api_key',
      label: 'API Key',
      required: true,
      type: 'string',
      helpText: 'Your Manus.ai API key. You can obtain this from your Manus.ai account settings.'
    }
  ],

  // Test function to validate the authentication
  test: testAuth,

  // Connection label to display in the Zapier UI
  connectionLabel: (z, bundle) => {
    return 'Manus.ai Account';
  }
};

