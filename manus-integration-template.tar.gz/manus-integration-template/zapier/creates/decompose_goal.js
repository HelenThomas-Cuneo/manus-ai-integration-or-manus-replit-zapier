/**
 * Decompose Goal Action
 * 
 * This action allows users to decompose a goal into executable steps using Manus.ai
 */

const perform = async (z, bundle) => {
  const response = await z.request({
    url: 'https://api.manus-ai.com/v2/decompose',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-API-Key': bundle.authData.api_key
    },
    body: {
      goal: bundle.inputData.goal,
      context: bundle.inputData.context || ''
    }
  });

  // Return the response data
  return response.json;
};

module.exports = {
  key: 'decompose_goal',
  noun: 'Goal',
  display: {
    label: 'Decompose Goal',
    description: 'Break down a goal into executable steps using Manus.ai',
    important: false
  },

  operation: {
    perform: perform,

    // Input fields that users will configure in Zapier
    inputFields: [
      {
        key: 'goal',
        label: 'Goal',
        type: 'text',
        helpText: 'The goal you want to decompose into steps',
        required: true,
        list: false,
        altersDynamicFields: false
      },
      {
        key: 'context',
        label: 'Context',
        type: 'text',
        helpText: 'Additional context or constraints for the goal (optional)',
        required: false,
        list: false
      }
    ],

    // Sample data for testing
    sample: {
      id: 'decompose_789012',
      goal: 'Plan a marketing campaign for product launch',
      steps: [
        {
          step: 1,
          title: 'Define target audience',
          description: 'Research and identify the primary target audience for the product'
        },
        {
          step: 2,
          title: 'Create content strategy',
          description: 'Develop a content calendar and messaging framework'
        },
        {
          step: 3,
          title: 'Set up advertising campaigns',
          description: 'Configure ads on relevant platforms (Google, Facebook, LinkedIn)'
        }
      ],
      estimated_duration: '3 weeks',
      created_at: '2024-10-13T12:00:00Z'
    },

    // Output fields that will be available in subsequent Zap steps
    outputFields: [
      { key: 'id', label: 'Decomposition ID', type: 'string' },
      { key: 'goal', label: 'Goal', type: 'string' },
      { key: 'steps', label: 'Steps', type: 'string' },
      { key: 'estimated_duration', label: 'Estimated Duration', type: 'string' },
      { key: 'created_at', label: 'Created At', type: 'datetime' }
    ]
  }
};

