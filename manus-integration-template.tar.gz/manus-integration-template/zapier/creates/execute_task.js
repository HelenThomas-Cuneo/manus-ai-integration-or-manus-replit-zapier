/**
 * Execute Task Action
 * 
 * This action allows users to execute a Manus.ai task from Zapier
 */

const perform = async (z, bundle) => {
  const response = await z.request({
    url: 'https://api.manus-ai.com/v2/execute',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-API-Key': bundle.authData.api_key
    },
    body: {
      goal: bundle.inputData.goal,
      inputs: bundle.inputData.inputs ? bundle.inputData.inputs.split(',').map(s => s.trim()) : [],
      constraints: {
        privacy: bundle.inputData.privacy || 'standard',
        deadline: bundle.inputData.deadline || null
      }
    }
  });

  // Return the response data
  return response.json;
};

module.exports = {
  key: 'execute_task',
  noun: 'Task',
  display: {
    label: 'Execute Task',
    description: 'Execute a task using the Manus.ai autonomous agent',
    important: true
  },

  operation: {
    perform: perform,

    // Input fields that users will configure in Zapier
    inputFields: [
      {
        key: 'goal',
        label: 'Task Goal',
        type: 'text',
        helpText: 'Describe the task you want Manus.ai to execute',
        required: true,
        list: false,
        altersDynamicFields: false
      },
      {
        key: 'inputs',
        label: 'Task Inputs',
        type: 'text',
        helpText: 'Comma-separated list of inputs for the task (optional)',
        required: false,
        list: false
      },
      {
        key: 'privacy',
        label: 'Privacy Mode',
        type: 'string',
        helpText: 'Privacy compliance mode (e.g., GDPR, HIPAA, or standard)',
        required: false,
        default: 'standard',
        choices: ['standard', 'GDPR', 'HIPAA']
      },
      {
        key: 'deadline',
        label: 'Deadline',
        type: 'datetime',
        helpText: 'Optional deadline for task completion (ISO 8601 format)',
        required: false
      }
    ],

    // Sample data for testing
    sample: {
      id: 'task_123456',
      goal: 'Analyze Q2 financial data and generate visualizations',
      status: 'completed',
      result: {
        summary: 'Analysis completed successfully',
        outputs: ['report.pdf', 'chart.png']
      },
      created_at: '2024-10-13T12:00:00Z',
      completed_at: '2024-10-13T12:05:30Z'
    },

    // Output fields that will be available in subsequent Zap steps
    outputFields: [
      { key: 'id', label: 'Task ID', type: 'string' },
      { key: 'goal', label: 'Goal', type: 'string' },
      { key: 'status', label: 'Status', type: 'string' },
      { key: 'result__summary', label: 'Result Summary', type: 'string' },
      { key: 'created_at', label: 'Created At', type: 'datetime' },
      { key: 'completed_at', label: 'Completed At', type: 'datetime' }
    ]
  }
};

