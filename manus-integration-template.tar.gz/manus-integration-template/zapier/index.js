/**
 * Manus.ai Integration for Zapier Platform
 * 
 * This is the main entry point for the Zapier integration.
 * It defines authentication, triggers, and actions for Manus.ai.
 */

const authentication = require('./authentication');
const executeTaskCreate = require('./creates/execute_task');
const decomposeGoalCreate = require('./creates/decompose_goal');
const taskCompletedTrigger = require('./triggers/task_completed');

module.exports = {
  // App version and metadata
  version: require('./package.json').version,
  platformVersion: require('zapier-platform-core').version,

  // Authentication configuration
  authentication: authentication,

  // Before request middleware (adds auth headers to all requests)
  beforeRequest: [
    (request, z, bundle) => {
      if (bundle.authData.api_key) {
        request.headers['X-API-Key'] = bundle.authData.api_key;
      }
      return request;
    }
  ],

  // After response middleware (handles errors)
  afterResponse: [
    (response, z, bundle) => {
      if (response.status === 401) {
        throw new z.errors.RefreshAuthError('Invalid API key');
      }
      if (response.status === 429) {
        throw new z.errors.ThrottledError('Rate limit exceeded');
      }
      return response;
    }
  ],

  // Triggers - when something happens in Manus.ai
  triggers: {
    [taskCompletedTrigger.key]: taskCompletedTrigger
  },

  // Searches - not implemented for this integration
  searches: {},

  // Creates - actions to perform in Manus.ai
  creates: {
    [executeTaskCreate.key]: executeTaskCreate,
    [decomposeGoalCreate.key]: decomposeGoalCreate
  },

  // Resources - reusable definitions (optional)
  resources: {}
};

