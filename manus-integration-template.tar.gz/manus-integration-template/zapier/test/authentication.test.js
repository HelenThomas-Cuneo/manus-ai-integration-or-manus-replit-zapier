/**
 * Tests for authentication
 */

const should = require('should');
const zapier = require('zapier-platform-core');

const App = require('../index');
const appTester = zapier.createAppTester(App);

describe('Authentication', () => {
  zapier.tools.env.inject();

  it('should authenticate with valid API key', async () => {
    const bundle = {
      authData: {
        api_key: process.env.MANUS_API_KEY || 'test_api_key'
      }
    };

    const result = await appTester(App.authentication.test, bundle);
    should.exist(result);
    result.should.have.property('status');
  });

  it('should fail authentication with invalid API key', async () => {
    const bundle = {
      authData: {
        api_key: 'invalid_key'
      }
    };

    try {
      await appTester(App.authentication.test, bundle);
      should.fail('Should have thrown an error');
    } catch (error) {
      should.exist(error);
    }
  });
});

