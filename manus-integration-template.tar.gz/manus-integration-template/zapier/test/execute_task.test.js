/**
 * Tests for execute_task action
 */

const should = require('should');
const zapier = require('zapier-platform-core');

const App = require('../index');
const appTester = zapier.createAppTester(App);

describe('Execute Task Action', () => {
  zapier.tools.env.inject();

  it('should execute a task', async () => {
    const bundle = {
      authData: {
        api_key: process.env.MANUS_API_KEY || 'test_api_key'
      },
      inputData: {
        goal: 'Test task execution',
        inputs: 'input1, input2',
        privacy: 'standard'
      }
    };

    const result = await appTester(
      App.creates.execute_task.operation.perform,
      bundle
    );

    should.exist(result);
    result.should.have.property('id');
    result.should.have.property('goal');
    result.should.have.property('status');
  });

  it('should handle missing optional fields', async () => {
    const bundle = {
      authData: {
        api_key: process.env.MANUS_API_KEY || 'test_api_key'
      },
      inputData: {
        goal: 'Test task with minimal input'
      }
    };

    const result = await appTester(
      App.creates.execute_task.operation.perform,
      bundle
    );

    should.exist(result);
    result.should.have.property('goal');
  });
});

