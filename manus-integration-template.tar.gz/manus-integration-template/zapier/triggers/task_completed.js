/**
 * Task Completed Trigger
 * 
 * This trigger fires when a Manus.ai task is completed
 * Uses polling to check for new completed tasks
 */

const perform = async (z, bundle) => {
  // Poll the Manus.ai API for completed tasks
  const response = await z.request({
    url: 'https://api.manus-ai.com/v2/tasks',
    method: 'GET',
    headers: {
      'X-API-Key': bundle.authData.api_key
    },
    params: {
      status: 'completed',
      since: bundle.meta.page ? bundle.meta.page : new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
      limit: 100
    }
  });

  // Return the array of completed tasks
  // Zapier will deduplicate based on the 'id' field
  return response.json.tasks || [];
};

module.exports = {
  key: 'task_completed',
  noun: 'Task',
  display: {
    label: 'Task Completed',
    description: 'Triggers when a Manus.ai task is completed',
    important: true
  },

  operation: {
    perform: perform,
    type: 'polling',

    // Input fields for configuring the trigger
    inputFields: [
      {
        key: 'task_type',
        label: 'Task Type',
        type: 'string',
        helpText: 'Filter by task type (optional)',
        required: false,
        list: false
      }
    ],

    // Sample data for testing
    sample: {
      id: 'task_123456',
      goal: 'Analyze Q2 financial data and generate visualizations',
      status: 'completed',
      result: {
        summary: 'Analysis completed successfully',
        outputs: ['report.pdf', 'chart.png']
      },
      created_at: '2024-10-13T12:00:00Z',
      completed_at: '2024-10-13T12:05:30Z'
    },

    // Output fields that will be available in subsequent Zap steps
    outputFields: [
      { key: 'id', label: 'Task ID', type: 'string' },
      { key: 'goal', label: 'Goal', type: 'string' },
      { key: 'status', label: 'Status', type: 'string' },
      { key: 'result__summary', label: 'Result Summary', type: 'string' },
      { key: 'result__outputs', label: 'Result Outputs', type: 'string' },
      { key: 'created_at', label: 'Created At', type: 'datetime' },
      { key: 'completed_at', label: 'Completed At', type: 'datetime' }
    ]
  }
};

